# KubeShop — commands for Parts 1–3 (replayed)

These commands were run before automatic recording started (2026-10-01, 06:05–06:50 UTC).
They are listed in the order they ran, with what each one proved. Lines marked **(sandbox only)** work around limits of the build machine; on a normal laptop you use the plain command shown next to them.

## Part 1 — the app and its images (Module 1)

```bash
# Lock files: run npm inside a container so you don't need Node.js on your laptop
cd Project/app/api    && docker run --rm -v "$(pwd)":/app -w /app node:24-alpine npm install --package-lock-only
cd Project/app/worker && docker run --rm -v "$(pwd)":/app -w /app node:24-alpine npm install --package-lock-only
#   (sandbox only) the build machine reaches npm through a proxy:
#   docker run --rm --network host -e HTTPS_PROXY -e npm_config_cafile=/ca.crt -v /root/.ccr/ca-bundle.crt:/ca.crt:ro ...
#   → express 5.2.1, pg 8.23.1, redis 5.12.1, prom-client 15.1.3

# Build the three images
cd Project/app
docker build -t kubeshop-api:1.0.0    ./api
docker build -t kubeshop-worker:1.0.0 ./worker
docker build -t kubeshop-web:1.0.0    ./web
#   (sandbox only) docker build --network host --build-arg HTTPS_PROXY -f Dockerfile.sandbox ...  (adds the proxy CA)
docker images | grep kubeshop          # web 81.6MB, worker 262MB, api 268MB
docker run --rm kubeshop-api:1.0.0 id  # uid=1000(node) — not root

# Run the whole shop locally with Compose
docker compose up -d --no-build --wait
curl -s localhost:8080/api/info        # {"service":"api","version":"1.0.0","color":"blue",...}
curl -s localhost:8080/api/products    # 4 products from Postgres
curl -s -X POST -H 'Content-Type: application/json' -d '{"productId":2,"quantity":1}' localhost:8080/api/orders
curl -s localhost:8080/api/orders/1    # status "processed" — the worker took it from the Redis queue
curl -s -o /dev/null -w '%{http_code}\n' -X POST -H 'Content-Type: application/json' -d '{"productId":99}' localhost:8080/api/orders   # 404
docker compose run --rm --no-deps -T migrate node report.js          # daily sales report as JSON
docker compose stop api worker         # 3.4 s: both log "SIGTERM received" and exit cleanly
docker compose down -v
```

## Part 2 — the cluster and raw manifests (Modules 2–9)

```bash
kind create cluster --config Project/kind-cluster.yaml
#   (sandbox only) the build machine runs cgroup v1, so its copy adds failCgroupV1: false
kubectl get nodes -L topology.kubernetes.io/zone        # 1 control plane + workers in zone-a/b/c

# Put the images into the cluster
kind load docker-image kubeshop-api:1.0.0 kubeshop-worker:1.0.0 kubeshop-web:1.0.0 --name kubeshop
#   base images (postgres:18-alpine, redis:8-alpine, nginx, busybox, metrics-server) loaded with
#   docker save --platform … -o image.tar IMAGE && kind load image-archive image.tar --name kubeshop

# metrics-server for kubectl top and the HPA (Module 7)
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/download/v0.9.0/components.yaml
kubectl patch deployment metrics-server -n kube-system --type=json \
  -p '[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]'

# The shop, in order
cd Project/k8s
kubectl apply -f 00-namespace.yaml -f 01-config.yaml -f 60-rbac.yaml
kubectl create secret generic shop-db -n shop --from-literal=password="$(openssl rand -hex 16)"
kubectl apply -f 10-postgres.yaml -f 11-redis.yaml
kubectl rollout status statefulset/postgres -n shop
kubectl get pvc -n shop                                   # two RWOP claims, Bound
kubectl apply -f 20-db-migrate-job.yaml
kubectl wait -n shop --for=condition=Complete job/db-migrate-1-0-0
kubectl apply -f 30-api.yaml -f 31-worker.yaml -f 32-web.yaml -f 40-daily-report-cronjob.yaml -f 50-availability.yaml
kubectl rollout status deploy/api -n shop

# Checks
kubectl get pods -n shop -o wide                          # one api Pod per zone
kubectl create job -n shop report-now --from=cronjob/daily-report
kubectl get hpa -n shop                                   # cpu: 10%/70%
kubectl auth can-i list secrets -n shop --as=dev --as-group=shop-developers        # no
kubectl auth can-i get pods --subresource=log -n shop --as=dev --as-group=shop-developers   # yes
kubectl run rooty -n shop --image=nginx:1.29-alpine       # Forbidden: violates PodSecurity "restricted"

# Node drain (Module 5/7)
kubectl drain kubeshop-worker3 --ignore-daemonsets --delete-emptydir-data
#   → postgres-0 Pending: its volume lives in zone-c   → api Pod Pending: zone spread counted the cordoned zone
#   fix: nodeTaintsPolicy: Honor in 30-api.yaml, then
kubectl apply -f 30-api.yaml && kubectl uncordon kubeshop-worker3
kubectl drain kubeshop-worker2 --ignore-daemonsets --delete-emptydir-data
#   → "Cannot evict pod as it would violate the pod's disruption budget" (retried), api moved to zone-a/c
kubectl uncordon kubeshop-worker2
```

## Part 3 — Gateway API, NetworkPolicies, Helm, blue/green (Module 10 + Advanced)

```bash
# Envoy Gateway (Gateway API controller) + cloud-provider-kind for the LoadBalancer IP
helm install eg oci://docker.io/envoyproxy/gateway-helm --version 1.9.2 -n envoy-gateway-system --create-namespace --wait
cloud-provider-kind                                       # second terminal
#   (sandbox only) a build of cloud-provider-kind without IPv6, and the Envoy images loaded with kind load
kubectl apply -f Project/platform/gateway/gateway.yaml
kubectl label ns shop gateway-access=true
kubectl apply -f Project/k8s/70-httproute.yaml
GW=$(kubectl get gateway public -n gateway -o jsonpath='{.status.addresses[0].value}')
curl -H "Host: shop.local" http://$GW/api/info           # api answers through Envoy

# NetworkPolicies
kubectl apply -f Project/k8s/80-networkpolicies.yaml
#   (sandbox only) kube-router as the policy engine: this kernel lacks nfnetlink_queue, which kindnet needs
kubectl exec -n shop deploy/web -- sh -c 'nc -z -w 3 postgres 5432 && echo open || echo blocked'   # blocked
curl -H "Host: shop.local" http://$GW/api/products       # still works

# Raw YAML → Helm (PVCs kept on purpose)
kubectl delete -f k8s/80-… -f k8s/01-config.yaml          # every file except 00-namespace; Secret and PVCs stay
helm install shop ./helm/kubeshop -n shop -f helm/kubeshop/values-kind.yaml --wait
curl -H "Host: shop.local" http://$GW/api/orders/3       # order created before the switch is still there

# Blue/green release of api 1.1.0
docker build -t kubeshop-api:1.1.0 ./app/api              # after the 1-line change in server.js
kind load docker-image kubeshop-api:1.1.0 --name kubeshop
helm upgrade shop ./helm/kubeshop -n shop -f helm/kubeshop/values-kind.yaml -f release.yaml   # 4 times:
#   green at 0%  → 50/50 blue   (x-color: green header reaches green)
#   90/10        → 46 blue, 4 green
#   0/100        → 50 green, orders return estimatedShipDays
#   blue off     → only api-green left
# Zero-downtime check: 10 requests/s while switching
#   one-step (add colour AND send 100%):   499 × 200, 40 × 503
#   three phases (add at 0% → shift → retire): 990 × 200, 0 errors
```
