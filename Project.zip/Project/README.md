# KubeShop — the end-to-end Kubernetes project

Part of the [course map](../CourseMap.html). A small but real online shop, taken from `docker build` to production on Amazon EKS. It has a web page, a REST API,
a background worker, PostgreSQL and Redis. Along the way it uses every module of the course.

Everything here was run, in order, while the project was built: on a 4-node kind cluster first, then in a real AWS
account. Then it was destroyed the same day. Every command and its real output is in [logs/COMMANDS.md](logs/COMMANDS.md).

| Open this | For |
|---|---|
| [ModuleMap.html](ModuleMap.html) | The project map: one diagram of all nine parts, with every step linked |
| [demo.html](demo.html) | The hands-on guide: 34 steps in 9 parts, with the commands, the real output and what to check |
| [Presentation.html](Presentation.html) | The slides, with architecture diagrams (arrow keys to move; print from the browser for handouts) |
| [Transcript.html](Transcript.html) | The recording script: 42 Udemy-style lectures, one per guide step, with what to say, show, type and point at |
| [runbooks/](runbooks/README.md) | What to do when each alert fires, plus releases, rollbacks, backups and teardown |
| [logs/COMMANDS.md](logs/COMMANDS.md) | Every command run, with exit code and output. Secrets and the AWS account ID are masked |

## How it fits together

```
 Internet ──► Gateway (Envoy, Gateway API) ──► /      ──► web (nginx, 2 Pods)
                                           └─► /api   ──► api-blue / api-green (Node.js, 3 Pods, HPA)
                                                               │  writes order (pending)   ▲ reads products (cached)
                                                               ▼                           │
                                                          PostgreSQL ◄──── worker ◄──── Redis queue
                                                          (StatefulSet,    marks order   (StatefulSet)
                                                           RWOP volume)    processed
 Argo CD keeps the cluster equal to Git · Prometheus, Loki and Grafana watch it · Alertmanager links every alert to a runbook
```

The diagrams in `demo.html` and `Presentation.html` show this in more detail: the order flow, NetworkPolicies, blue/green,
GitOps, observability, kind vs EKS, and the AWS layout.

## What each course module contributes

| Module | Where it shows up in KubeShop |
|---|---|
| 1 Docker | `app/*/Dockerfile`: multi-stage, non-root images; `app/compose.yaml` runs the shop locally |
| 2 Architecture & kubectl | `kind-cluster.yaml`: 1 control plane + 3 workers labelled as three zones |
| 3 Pods & Services | ClusterIP Services for every component; `/healthz` and `/readyz` |
| 4 Namespaces, labels, Deployments | `shop` namespace with Pod Security `restricted`; rolling updates with `maxUnavailable: 0` |
| 5 Scaling, maintenance, Jobs | `db-migrate` Job, `daily-report` CronJob, a node drain drill (`runbooks/node-maintenance.md`) |
| 6 ConfigMaps, Secrets, init containers | `shop-config`, `shop-db` (never in Git), a wait-for-database init container |
| 7 Resources, probes, scheduling | requests and limits, startup/readiness/liveness probes, zone spread, PDBs, HPA |
| 8 Storage | StatefulSets with `ReadWriteOncePod` volumes; gp3 encrypted EBS on EKS |
| 9 RBAC | `shop-developers` Role (read Pods and logs, no Secrets); EKS Pod Identity for AWS access |
| 10 Ingress, NetworkPolicy, Helm | Gateway API routes, default-deny NetworkPolicies, the `helm/kubeshop` chart |
| Advanced: blue/green | `release-*.yaml`: three-commit releases with weighted routes, measured at 0 failed requests |
| Beyond the course | Argo CD app-of-apps, Prometheus/Loki/Grafana/Alloy, alerts with runbooks, Terraform, Karpenter Spot, ECR scanning |

## Folder layout

```
app/          web, api and worker source code, Dockerfiles, compose.yaml
k8s/          the shop as plain YAML, numbered in apply order (Part C–D of the guide)
helm/kubeshop the same shop as a Helm chart, with values and release files for kind and EKS
platform/     Gateway, Argo CD, monitoring, and for EKS: gp3 storage, Karpenter, an NLB-backed Gateway
gitops/       Argo CD Applications: bootstrap/, kind/, eks/
infra/eks/    Terraform: VPC, EKS 1.36, node group, add-ons, IAM (Pod Identity), ECR, platform Helm releases
tests/        Karpenter inflate Deployment and the traffic probe used during releases
tools/        rec (command recorder), promq (PromQL from the terminal), push-images, eks-env, kind-preload
runbooks/     alert runbooks and day-2 operations
logs/         COMMANDS.md (recorded run) and COMMANDS-parts-1-3.md (the first three parts, replayed)
```

## Quick start on kind

You need Docker, kind 0.33 or later, kubectl, Helm 4 and git, plus about 4 CPUs and 12 GB RAM free.
Fork the repository first, because Argo CD deploys from *your* copy.

```bash
git clone https://github.com/<you>/kubernetes-2026.git && cd kubernetes-2026/Project
kind create cluster --config kind-cluster.yaml
```

Then follow [demo.html](demo.html) from Step 1. Parts A to G run entirely on your laptop and cost nothing.

## On Amazon EKS (Part H, costs money)

About **$0.37 an hour** while it runs. The cluster was up about 1½ hours for the full test, which cost under a dollar. You need the AWS CLI v2,
Terraform 1.10 or later, and an account where you may create a VPC, EKS and IAM roles.

```bash
aws iam create-service-linked-role --aws-service-name spot.amazonaws.com   # once per account, for Karpenter
cd infra/eks && terraform init && terraform plan -out=eks.tfplan           # read the plan, then:
terraform apply eks.tfplan
```

Steps 25–33 of the guide go on from there: ECR, GitOps, the NLB, Karpenter and a blue/green release.
**Tear down the same day, in the order of [runbooks/teardown-eks.md](runbooks/teardown-eks.md).** The NLB, EBS volumes and Spot
nodes are created by controllers inside the cluster, so `terraform destroy` alone would leave them behind.

## What the test runs found (and what was changed)

| Found | Fixed in |
|---|---|
| A drain left an api Pod Pending: zone spread counted the cordoned node | `nodeTaintsPolicy: Honor` in the api spread constraint |
| Turning green on and sending it 100 % in one step: 40 of 539 requests failed | three-commit release; 0 of 990 failed on kind, 0 of 7,878 on EKS |
| api and worker crashed when Postgres restarted (`Unhandled 'error' event`) | pool error handler in both, plus a requeue in the worker |
| Pausing one Argo CD app didn't stick: its parent re-enabled it | `runbooks/pause-gitops.md`: pause `root` first |
| Argo CD showed OutOfSync for fields the API server fills in | the chart writes them out explicitly |
| EKS HPA showed `<unknown>`: no metrics-server on EKS by default | metrics-server EKS add-on in `infra/eks/eks.tf` |
| ECR "had no scan" for a tag: the tag points to an OCI index | read findings by the image manifest's digest |
| web image: 13 critical CVEs in the base image's curl and openssl | web 1.0.1 upgrades the packages and removes curl: 0 findings |
| Karpenter couldn't launch Spot: no EC2 Spot service-linked role in a new account | one-time `create-service-linked-role` in the guide |

## Security notes

- No credentials are stored in this repository. AWS credentials stay in your AWS CLI config or environment. The Argo CD
  repository token and the two passwords are created as Kubernetes Secrets by hand.
- `tools/rec` masks AWS keys, tokens and 12-digit account IDs before anything is written to `logs/COMMANDS.md`.
- `helm/kubeshop/values-eks.yaml` and `gitops/eks/` hold the placeholder `ACCOUNT_ID` and `main`. `tools/eks-env <account> [branch]`
  fills them in for your own fork.
