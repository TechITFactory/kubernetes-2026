{{- define "kubeshop.labels" -}}
app.kubernetes.io/part-of: kubeshop
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/* image "name" "tag" → registry/name:tag */}}
{{- define "kubeshop.image" -}}
{{- $root := index . 0 -}}{{- $name := index . 1 -}}{{- $tag := index . 2 -}}
{{- with $root.Values.global.imageRegistry }}{{ . }}/{{ end }}{{ $name }}:{{ $tag }}
{{- end }}

{{- define "kubeshop.podSecurity" -}}
runAsNonRoot: true
runAsUser: {{ . }}
seccompProfile:
  type: RuntimeDefault
{{- end }}

{{- define "kubeshop.containerSecurity" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop: ["ALL"]
{{- end }}

{{- define "kubeshop.dbEnv" -}}
envFrom:
  - configMapRef:
      name: shop-config
env:
  - name: PGPASSWORD
    valueFrom:
      secretKeyRef:
        name: {{ .Values.database.existingSecret }}
        key: {{ .Values.database.passwordKey }}
{{- end }}
