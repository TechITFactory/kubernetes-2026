// Order worker: waits for order IDs on a Redis list, then marks them processed in Postgres.
const http = require('http');
const os = require('os');
const { Pool } = require('pg');
const { createClient } = require('redis');
const client = require('prom-client');

const QUEUE = process.env.ORDER_QUEUE || 'orders';
const METRICS_PORT = Number(process.env.METRICS_PORT || 9100);
const WORK_MS = Number(process.env.WORK_MS || 200);   // pretend each order takes this long

function log(level, msg, extra = {}) {
  console.log(JSON.stringify({ time: new Date().toISOString(), level, msg, worker: os.hostname(), ...extra }));
}

const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: Number(process.env.PGPORT || 5432),
  user: process.env.PGUSER || 'shop',
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE || 'shop',
  max: 2,
});
const redis = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
pool.on('error', (err) => log('warn', 'idle database connection lost', { err: err.message }));   // see api/db.js
redis.on('error', (err) => log('error', 'redis error', { err: err.message }));

client.collectDefaultMetrics();
const processed = new client.Counter({ name: 'kubeshop_orders_processed_total', help: 'Orders processed' });
const queueDepth = new client.Gauge({
  name: 'kubeshop_order_queue_depth', help: 'Orders waiting in the queue',
  async collect() { try { this.set(await redis.lLen(QUEUE)); } catch { /* redis down: keep last value */ } },
});

let running = true;
let lastLoop = Date.now();

// Metrics + liveness on one small HTTP server. /healthz fails if the loop is stuck for 60s.
http.createServer(async (req, res) => {
  if (req.url === '/healthz') {
    const ok = Date.now() - lastLoop < 60000;
    res.writeHead(ok ? 200 : 500, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ status: ok ? 'ok' : 'stuck' }));
  }
  if (req.url === '/metrics') {
    res.writeHead(200, { 'Content-Type': client.register.contentType });
    return res.end(await client.register.metrics());
  }
  res.writeHead(404); res.end();
}).listen(METRICS_PORT);

async function loop() {
  while (running) {
    lastLoop = Date.now();
    const item = await redis.brPop(QUEUE, 5);   // wait up to 5 s, then loop again
    if (!item) continue;
    const orderId = Number(item.element);
    await new Promise((r) => setTimeout(r, WORK_MS));
    try {
      const { rowCount } = await pool.query(
        "UPDATE orders SET status = 'processed', processed_at = now() WHERE id = $1 AND status = 'pending'", [orderId]);
      processed.inc();
      log('info', 'order processed', { orderId, updated: rowCount });
    } catch (err) {
      // database unavailable: put the order back at the end of the queue and slow down
      log('error', 'order failed, requeued', { orderId, err: err.message });
      await redis.rPush(QUEUE, String(orderId));
      await new Promise((r) => setTimeout(r, 2000));
    }
  }
}

async function main() {
  await redis.connect();
  log('info', 'worker started', { queue: QUEUE });
  process.on('SIGTERM', () => { log('info', 'SIGTERM received, finishing current order'); running = false; });
  await loop();
  await Promise.allSettled([pool.end(), redis.quit()]);
  log('info', 'worker stopped');
  process.exit(0);
}

main().catch((err) => { log('error', 'worker crashed', { err: err.message }); process.exit(1); });
