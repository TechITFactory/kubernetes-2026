// The browser calls /api/... on the same host. The Gateway (or Ingress) sends /api to the API Service.
const $ = (id) => document.getElementById(id);
const money = (cents) => (cents / 100).toLocaleString('en-US', { style: 'currency', currency: 'USD' });

async function load() {
  const info = await fetch('/api/info').then((r) => r.json());
  $('info').textContent = `api ${info.version} · ${info.color} · served by ${info.pod}`;
  const products = await fetch('/api/products').then((r) => r.json());
  $('products').innerHTML = '';
  for (const p of products) {
    const li = document.createElement('li');
    li.innerHTML = `<div><b></b><small></small></div><button type="button">Buy</button>`;
    li.querySelector('b').textContent = p.name;
    li.querySelector('small').textContent = `${money(p.price_cents)} · ${p.stock} in stock`;
    li.querySelector('button').onclick = () => order(p.id);
    $('products').appendChild(li);
  }
}

async function order(productId) {
  const res = await fetch('/api/orders', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productId, quantity: 1 }),
  });
  const o = await res.json();
  $('status').textContent = res.ok ? `Order #${o.id} is ${o.status}…` : `Error: ${o.error}`;
  if (!res.ok) return;
  setTimeout(async () => {
    const done = await fetch(`/api/orders/${o.id}`).then((r) => r.json());
    $('status').textContent = `Order #${done.id} is ${done.status}.`;
  }, 1500);
}

load().catch((err) => { $('info').textContent = `API not reachable: ${err.message}`; });
