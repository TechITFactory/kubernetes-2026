const os = require('os');
const express = require('express');
const client = require('prom-client');
const { pool, redis, log } = require('./db');

const PORT = Number(process.env.PORT || 8080);
const VERSION = process.env.APP_VERSION || 'dev';
const COLOR = process.env.APP_COLOR || 'blue';
const QUEUE = process.env.ORDER_QUEUE || 'orders';
const CACHE_SECONDS = Number(process.env.CACHE_SECONDS || 30);

// ---- metrics (scraped by Prometheus) ----
client.collectDefaultMetrics();
const httpRequests = new client.Counter({
  name: 'kubeshop_http_requests_total', help: 'HTTP requests', labelNames: ['method', 'route', 'status'],
});
const ordersCreated = new client.Counter({ name: 'kubeshop_orders_created_total', help: 'Orders accepted' });
const httpDuration = new client.Histogram({
  name: 'kubeshop_http_request_duration_seconds', help: 'HTTP request duration',
  labelNames: ['method', 'route'], buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5],
});

const app = express();
app.use(express.json({ limit: '10kb' }));
app.use((req, res, next) => {
  const end = httpDuration.startTimer();
  res.on('finish', () => {
    const route = req.route ? req.route.path : 'unmatched';
    httpRequests.inc({ method: req.method, route, status: res.statusCode });
    end({ method: req.method, route });
  });
  next();
});

let shuttingDown = false;

// Liveness: is the process able to answer at all? Never check dependencies here.
app.get('/healthz', (req, res) => res.json({ status: 'ok' }));

// Readiness: can we serve real traffic right now? Checks Postgres and Redis.
app.get('/readyz', async (req, res) => {
  if (shuttingDown) return res.status(503).json({ status: 'shutting down' });
  try {
    await pool.query('SELECT 1');
    await redis.ping();
    res.json({ status: 'ready' });
  } catch (err) {
    res.status(503).json({ status: 'not ready', error: err.message });
  }
});

app.get('/metrics', async (req, res) => {
  res.set('Content-Type', client.register.contentType);
  res.end(await client.register.metrics());
});

app.get('/api/info', (req, res) => {
  res.json({ service: 'api', version: VERSION, color: COLOR, pod: os.hostname() });
});

app.get('/api/products', async (req, res, next) => {
  try {
    const cached = await redis.get('products');
    if (cached) return res.set('X-Cache', 'HIT').json(JSON.parse(cached));
    const { rows } = await pool.query('SELECT id, name, price_cents, stock FROM products ORDER BY id');
    await redis.set('products', JSON.stringify(rows), { EX: CACHE_SECONDS });
    res.set('X-Cache', 'MISS').json(rows);
  } catch (err) { next(err); }
});

app.post('/api/orders', async (req, res, next) => {
  const productId = Number(req.body?.productId);
  const quantity = Number(req.body?.quantity ?? 1);
  if (!Number.isInteger(productId) || !Number.isInteger(quantity) || quantity < 1 || quantity > 10) {
    return res.status(400).json({ error: 'productId and quantity (1-10) are required integers' });
  }
  try {
    const { rows } = await pool.query(
      `INSERT INTO orders (product_id, quantity, status)
       SELECT id, $2, 'pending' FROM products WHERE id = $1
       RETURNING id, product_id, quantity, status, created_at`, [productId, quantity]);
    if (rows.length === 0) return res.status(404).json({ error: 'product not found' });
    await redis.lPush(QUEUE, String(rows[0].id));   // the worker picks it up
    ordersCreated.inc();
    log('info', 'order created', { orderId: rows[0].id, productId, quantity });
    res.status(201).json(rows[0]);
  } catch (err) { next(err); }
});

app.get('/api/orders/:id', async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      'SELECT id, product_id, quantity, status, created_at, processed_at FROM orders WHERE id = $1', [Number(req.params.id)]);
    if (rows.length === 0) return res.status(404).json({ error: 'order not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

app.use((err, req, res, next) => {   // eslint-disable-line no-unused-vars
  log('error', 'request failed', { path: req.path, err: err.message });
  res.status(500).json({ error: 'internal error' });
});

async function main() {
  await redis.connect();
  const server = app.listen(PORT, () => log('info', 'api listening', { port: PORT, version: VERSION, color: COLOR }));

  // Graceful shutdown (Module 1, Step 16 and Module 7): stop being ready, finish requests, close connections.
  process.on('SIGTERM', () => {
    log('info', 'SIGTERM received, draining');
    shuttingDown = true;
    server.close(async () => {
      await Promise.allSettled([pool.end(), redis.quit()]);
      log('info', 'shutdown complete');
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 20000).unref();
  });
}

main().catch((err) => { log('error', 'startup failed', { err: err.message }); process.exit(1); });
