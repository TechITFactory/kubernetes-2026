// Shared connections. Every setting comes from environment variables (Module 6: ConfigMap + Secret).
const { Pool } = require('pg');
const { createClient } = require('redis');

const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: Number(process.env.PGPORT || 5432),
  user: process.env.PGUSER || 'shop',
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE || 'shop',
  max: Number(process.env.PG_POOL_MAX || 5),
  connectionTimeoutMillis: 3000,
});

const redis = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
// When Postgres restarts it closes idle connections. Without this handler Node.js treats that
// as an unhandled 'error' event and the whole process crashes (found in the database-down drill).
pool.on('error', (err) => log('warn', 'idle database connection lost', { err: err.message }));
redis.on('error', (err) => log('error', 'redis error', { err: err.message }));

function log(level, msg, extra = {}) {
  // One JSON object per line: easy to search once logs are collected (Project Part H).
  console.log(JSON.stringify({ time: new Date().toISOString(), level, msg, ...extra }));
}

module.exports = { pool, redis, log };
