// Database migrations. Runs as a Kubernetes Job (Module 5) before the API starts serving.
const { pool, log } = require('./db');

const MIGRATIONS = [
  `CREATE TABLE IF NOT EXISTS products (
     id SERIAL PRIMARY KEY,
     name TEXT NOT NULL UNIQUE,
     price_cents INTEGER NOT NULL CHECK (price_cents >= 0),
     stock INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS orders (
     id SERIAL PRIMARY KEY,
     product_id INTEGER NOT NULL REFERENCES products(id),
     quantity INTEGER NOT NULL CHECK (quantity > 0),
     status TEXT NOT NULL DEFAULT 'pending',
     created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
     processed_at TIMESTAMPTZ)`,
  `INSERT INTO products (name, price_cents, stock) VALUES
     ('Kubernetes Mug', 1299, 100),
     ('Helm Hoodie', 4999, 40),
     ('Pod Plushie', 1999, 75),
     ('YAML Sticker Pack', 499, 500)
   ON CONFLICT (name) DO NOTHING`,
];

async function main() {
  for (let attempt = 1; attempt <= 30; attempt++) {
    try { await pool.query('SELECT 1'); break; } catch (err) {
      log('info', 'waiting for database', { attempt, err: err.message });
      await new Promise((r) => setTimeout(r, 2000));
      if (attempt === 30) throw err;
    }
  }
  for (const [i, sql] of MIGRATIONS.entries()) {
    await pool.query(sql);
    log('info', 'migration applied', { step: i + 1 });
  }
  const { rows } = await pool.query('SELECT count(*)::int AS products FROM products');
  log('info', 'migrations complete', rows[0]);
  await pool.end();
}

main().catch((err) => { log('error', 'migration failed', { err: err.message }); process.exit(1); });
