// Nightly sales report. Runs as a Kubernetes CronJob (Module 5).
const { pool, log } = require('./db');

async function main() {
  const { rows } = await pool.query(
    `SELECT p.name, count(o.id)::int AS orders, coalesce(sum(o.quantity * p.price_cents), 0)::int AS revenue_cents
       FROM products p LEFT JOIN orders o ON o.product_id = p.id AND o.created_at > now() - interval '1 day'
      GROUP BY p.name ORDER BY revenue_cents DESC`);
  const total = rows.reduce((s, r) => s + r.revenue_cents, 0);
  log('info', 'daily sales report', { totalRevenueCents: total, byProduct: rows });
  await pool.end();
}

main().catch((err) => { log('error', 'report failed', { err: err.message }); process.exit(1); });
