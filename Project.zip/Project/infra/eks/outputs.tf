output "configure_kubectl" {
  value = "aws eks update-kubeconfig --region ${var.region} --name ${module.eks.cluster_name}"
}

output "ecr_registry" {
  value = split("/", aws_ecr_repository.app["kubeshop-api"].repository_url)[0]
}

output "karpenter_node_role" {
  value = module.karpenter.node_iam_role_name
}

output "vpc_id" {
  value = module.vpc.vpc_id
}
