terraform {
  required_version = ">= 1.10"
  required_providers {
    aws  = { source = "hashicorp/aws", version = "~> 6.67" }
    helm = { source = "hashicorp/helm", version = "~> 3.3" }
  }
  # Teams keep state in S3 (native locking since Terraform 1.10). A lab can use local state.
  # backend "s3" {
  #   bucket       = "my-terraform-state"
  #   key          = "kubeshop/eks.tfstate"
  #   region       = "us-east-1"
  #   use_lockfile = true
  # }
}

provider "aws" {
  region = var.region
  default_tags {
    tags = { Project = "kubeshop", ManagedBy = "terraform" } # every resource is easy to find and to cost
  }
}

# Helm talks to the new cluster with a short-lived token from the AWS CLI — no kubeconfig file needed.
provider "helm" {
  kubernetes = {
    host                   = module.eks.cluster_endpoint
    cluster_ca_certificate = base64decode(module.eks.cluster_certificate_authority_data)
    exec = {
      api_version = "client.authentication.k8s.io/v1beta1"
      command     = "aws"
      args        = ["eks", "get-token", "--cluster-name", module.eks.cluster_name, "--region", var.region]
    }
  }
}
