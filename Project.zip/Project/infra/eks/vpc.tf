data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  azs = slice(data.aws_availability_zones.available.names, 0, 3)
}

# A VPC across 3 AZs: public subnets for the load balancer, private subnets for nodes and Pods.
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 6.7"

  name = var.cluster_name
  cidr = "10.0.0.0/16"
  azs  = local.azs

  private_subnets = ["10.0.0.0/19", "10.0.32.0/19", "10.0.64.0/19"]
  public_subnets  = ["10.0.96.0/24", "10.0.97.0/24", "10.0.98.0/24"]

  enable_nat_gateway = true
  single_nat_gateway = true # one NAT saves ~$65/month; production uses one per AZ

  public_subnet_tags = {
    "kubernetes.io/role/elb" = 1 # internet-facing load balancers go here
  }
  private_subnet_tags = {
    "kubernetes.io/role/internal-elb" = 1
    "karpenter.sh/discovery"          = var.cluster_name # Karpenter launches nodes here
  }
}
