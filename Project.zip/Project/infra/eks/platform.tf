# Platform bootstrap: the few things that must exist before Argo CD can take over.
# Everything else (Gateway, storage class, Karpenter NodePool, monitoring, the shop) comes from Git via Argo CD.

resource "helm_release" "aws_load_balancer_controller" {
  name       = "aws-load-balancer-controller"
  namespace  = "kube-system"
  repository = "https://aws.github.io/eks-charts"
  chart      = "aws-load-balancer-controller"
  version    = "3.5.0"
  values = [yamlencode({
    clusterName    = module.eks.cluster_name
    region         = var.region
    vpcId          = module.vpc.vpc_id
    serviceAccount = { name = "aws-load-balancer-controller" }
  })]
  depends_on = [module.eks, module.lb_controller_pod_identity]
}

resource "helm_release" "karpenter" {
  name       = "karpenter"
  namespace  = "kube-system"
  repository = "oci://public.ecr.aws/karpenter"
  chart      = "karpenter"
  version    = "1.14.1"
  values = [yamlencode({
    settings = {
      clusterName       = module.eks.cluster_name
      interruptionQueue = module.karpenter.queue_name
    }
    controller = { resources = { requests = { cpu = "100m", memory = "256Mi" } } }
  })]
  depends_on = [module.eks, module.karpenter]
}

resource "helm_release" "envoy_gateway" {
  name             = "eg"
  namespace        = "envoy-gateway-system"
  create_namespace = true
  repository       = "oci://docker.io/envoyproxy"
  chart            = "gateway-helm"
  version          = "1.9.2"
  depends_on       = [module.eks]
}

resource "helm_release" "argocd" {
  name             = "argocd"
  namespace        = "argocd"
  create_namespace = true
  repository       = "https://argoproj.github.io/argo-helm"
  chart            = "argo-cd"
  version          = "10.9.5"
  values           = [file("${path.module}/../../platform/argocd/values.yaml")]
  depends_on       = [module.eks]
}
