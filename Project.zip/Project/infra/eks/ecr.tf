# One private registry per image. Images are scanned on push; only the newest 20 are kept.
resource "aws_ecr_repository" "app" {
  for_each             = toset(["kubeshop-web", "kubeshop-api", "kubeshop-worker"])
  name                 = each.key
  image_tag_mutability = "IMMUTABLE" # a tag always means the same image — rollbacks are trustworthy
  force_delete         = true        # lets terraform destroy remove repositories that still hold images

  image_scanning_configuration {
    scan_on_push = true
  }
}

resource "aws_ecr_lifecycle_policy" "app" {
  for_each   = aws_ecr_repository.app
  repository = each.value.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "keep the newest 20 images"
      selection    = { tagStatus = "any", countType = "imageCountMoreThan", countNumber = 20 }
      action       = { type = "expire" }
    }]
  })
}
