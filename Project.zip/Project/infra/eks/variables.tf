variable "region" {
  type    = string
  default = "us-east-1"
}

variable "cluster_name" {
  type    = string
  default = "kubeshop"
}

variable "kubernetes_version" {
  type    = string
  default = "1.36"
}

variable "node_instance_type" {
  description = "Fixed nodes for the platform and the shop. New accounts often allow only 5 On-Demand vCPUs: 2 x t3.large = 4."
  type        = string
  default     = "t3.large"
}

variable "node_count" {
  type    = number
  default = 2
}
