# The EKS cluster, its managed add-ons and one managed node group.
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 21.26"

  name               = var.cluster_name
  kubernetes_version = var.kubernetes_version

  endpoint_public_access                   = true # kubectl from your laptop; production often restricts the CIDRs
  enable_cluster_creator_admin_permissions = true # whoever runs terraform gets cluster-admin (access entry)

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets

  addons = {
    vpc-cni = {
      before_compute = true
      # the VPC CNI enforces NetworkPolicy itself — our default-deny policies work on EKS too
      configuration_values = jsonencode({ enableNetworkPolicy = "true" })
    }
    eks-pod-identity-agent = { before_compute = true }
    coredns                = {}
    kube-proxy             = {}
    metrics-server         = {} # the HPA and kubectl top need it; EKS doesn't install it by default
    aws-ebs-csi-driver = {
      pod_identity_association = [{
        role_arn        = module.ebs_csi_pod_identity.iam_role_arn
        service_account = "ebs-csi-controller-sa"
      }]
    }
  }

  eks_managed_node_groups = {
    system = {
      ami_type       = "AL2023_x86_64_STANDARD"
      instance_types = [var.node_instance_type]
      min_size       = var.node_count
      max_size       = var.node_count
      desired_size   = var.node_count
      labels         = { "kubeshop.io/pool" = "system" }
    }
  }

  node_security_group_tags = {
    "karpenter.sh/discovery" = var.cluster_name # Karpenter's nodes join with the same security group
  }
}
