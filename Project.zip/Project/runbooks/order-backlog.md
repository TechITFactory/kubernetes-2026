# KubeShopOrderBacklog

**Means:** more than 50 orders have been waiting in the Redis queue for 10 minutes. Customers' orders stay "pending".

```bash
kubectl exec -n shop redis-0 -- redis-cli LLEN orders
kubectl get pods -n shop -l app.kubernetes.io/name=worker
kubectl logs -n shop -l app.kubernetes.io/name=worker --tail=50 | grep -E 'failed|error'
```

- Workers log `order failed, requeued` → the database is the problem: [database-down.md](database-down.md).
- Workers healthy but slow → more workers: raise `worker.replicas` in Git. The queue is shared, so extra workers help at once.
- No worker Pods → check the Deployment events and image (same table as [api-down.md](api-down.md)).
