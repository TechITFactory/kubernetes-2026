# Back up and restore the database

```bash
# backup: a compressed custom-format dump, written to your machine
kubectl exec -n shop postgres-0 -- pg_dump -U shop -d shop --format=custom > shop-$(date +%F).dump

# restore (replaces the tables)
kubectl exec -i -n shop postgres-0 -- pg_restore -U shop -d shop --clean --if-exists < shop-2026-10-01.dump
kubectl exec -n shop postgres-0 -- psql -U shop -d shop -tAc "select count(*) from orders"
```

**Verified:** 349 orders → `delete from orders` → 0 → restore → 349.

**Production:** run the dump as a nightly CronJob that uploads to S3 (EKS Pod Identity gives it the S3 permission), or use RDS automated backups with point-in-time recovery.
