# KubeShop runbooks

A runbook says what to do when something happens — written calmly, in advance, so nobody has to think from scratch at 3 a.m.
Every alert links to its runbook (`runbook_url` in [kubeshop-alerts.yaml](../platform/monitoring/extras/kubeshop-alerts.yaml)).
Every command here was run on the KubeShop cluster while writing this; see [logs/COMMANDS.md](../logs/COMMANDS.md).

## Alerts

| Alert | Severity | Runbook |
|---|---|---|
| KubeShopApiHighErrorRate | critical | [api-high-error-rate.md](api-high-error-rate.md) |
| KubeShopApiDown | critical | [api-down.md](api-down.md) |
| KubeShopDatabaseDown | critical | [database-down.md](database-down.md) |
| KubeShopApiSlow | warning | [api-slow.md](api-slow.md) |
| KubeShopOrderBacklog | warning | [order-backlog.md](order-backlog.md) |
| KubeShopPodRestarting | warning | [pod-restarting.md](pod-restarting.md) |

## Operations

| Task | Runbook |
|---|---|
| Ship a new API version (blue/green through Git) | [release.md](release.md) |
| Roll back a bad release | [rollback.md](rollback.md) |
| Pause GitOps before touching the cluster by hand | [pause-gitops.md](pause-gitops.md) |
| Back up and restore the database | [backup-restore.md](backup-restore.md) |
| Rotate the database password | [rotate-db-password.md](rotate-db-password.md) |
| Node maintenance (drain, upgrade, return) | [node-maintenance.md](node-maintenance.md) |
| Tear down EKS without leaving billable leftovers | [teardown-eks.md](teardown-eks.md) |

## First five minutes of any incident

```bash
kubectl get applications -n argocd                  # is GitOps healthy? what changed recently?
kubectl get pods -n shop -o wide                    # anything not Running/Ready? on which node?
kubectl get events -n shop --sort-by=.lastTimestamp | tail -20
kubectl logs -n shop deploy/api-green -c api --tail=50   # use api-blue if blue is live
tools/promq 'ALERTS{alertstate="firing"}'           # what else is firing?
```
