# KubeShopApiHighErrorRate

**Means:** more than 5 % of `/api` requests returned 5xx for 5 minutes.

## Check

```bash
tools/promq 'sum by (route, status) (rate(kubeshop_http_requests_total{route=~"/api.*",status=~"5.."}[5m]))'
kubectl logs -n shop -l app.kubernetes.io/name=api -c api --tail=100 | grep '"level":"error"'
kubectl get applications -n argocd kubeshop -o jsonpath='{.status.sync.revision}'; echo   # what was deployed last?
```

In Grafana (`grafana.local`, dashboard **KubeShop**): *Error rate*, *Requests per API Pod (blue / green)* and *Error logs*.

| Pattern | Likely cause | Fix |
|---|---|---|
| Errors only on one colour | The new release is broken | Shift traffic back: [rollback.md](rollback.md) |
| Errors on every route, logs say database | Postgres problem | [database-down.md](database-down.md) |
| Errors started right after a commit | Bad config or values | `git revert` the commit — Argo CD rolls it back |
