# KubeShopApiDown

**Means:** Prometheus can't scrape any `api-*` Pod for 2 minutes. **Impact:** the whole shop API is down.

## Check

```bash
kubectl get deploy,pods -n shop -l app.kubernetes.io/name=api -o wide
kubectl describe pod -n shop -l app.kubernetes.io/name=api | grep -A10 Events | tail -20
kubectl get hpa -n shop
```

| You see | Cause | Fix |
|---|---|---|
| `ImagePullBackOff` | Wrong tag in `release-*.yaml`, or the image isn't in the registry | Fix the tag in Git; `maxUnavailable: 0` keeps the old Pods serving meanwhile |
| `Init:0/1` for a long time | `wait-for-postgres` is waiting | See [database-down.md](database-down.md) |
| `CrashLoopBackOff` | The app crashes at start-up | `kubectl logs <pod> -c api --previous`; roll back ([rollback.md](rollback.md)) |
| `Pending` | No room or zone rule can't be met | `kubectl describe pod` → Events. Topology spread uses `nodeTaintsPolicy: Honor`, so drained zones are ignored |
| Pods fine, alert still firing | Prometheus can't reach them | NetworkPolicy `monitoring-scrape` must allow namespace `monitoring` on 8080 |
