# KubeShopPodRestarting

**Means:** a Pod in `shop` restarted more than 3 times in 15 minutes.

```bash
kubectl get pods -n shop                                   # RESTARTS column
kubectl describe pod <pod> -n shop | grep -A5 'Last State'  # Reason: OOMKilled? Error? exit code?
kubectl logs <pod> -n shop --previous --tail=50            # logs from the crash, not the new start
```

| Last State | Meaning | Fix |
|---|---|---|
| `OOMKilled` | Hit its memory limit | Raise the limit in values, or find the leak |
| `Error`, logs show `Unhandled 'error' event` | App bug | Real example from this project: Postgres restarts closed idle connections and crashed Node.js. Fixed with `pool.on('error', …)` in `app/api/db.js` |
| Liveness probe failed | App hung, or the probe is too strict | Check `/healthz` timing; the liveness probe must never depend on other services |
