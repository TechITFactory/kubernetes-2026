# KubeShopDatabaseDown

**Means:** the `postgres` StatefulSet has no ready replica for 2 minutes.
**Impact:** new orders fail (HTTP 500). Product pages keep working for up to 30 s from the Redis cache. API Pods turn *not ready* (their `/readyz` checks Postgres). Orders already in the queue wait — the worker puts them back and retries.

## Check

```bash
kubectl get pods -n shop -l app.kubernetes.io/name=postgres -o wide
kubectl describe pod postgres-0 -n shop | tail -20       # Events: scheduling? volume? OOMKilled?
kubectl logs postgres-0 -n shop --tail=50
kubectl get pvc -n shop data-postgres-0
```

| You see | Cause | Fix |
|---|---|---|
| `Pending` … *didn't match PersistentVolume's node affinity* | The volume lives in one zone and that zone's node is drained or gone | `kubectl uncordon <node>`; on EKS wait for/replace a node **in the same AZ** |
| `0/0` replicas | Someone scaled it down | Resume GitOps ([pause-gitops.md](pause-gitops.md)) — Argo CD restores 1 replica |
| `CrashLoopBackOff`, logs show disk full | Volume full | Expand the PVC (`kubectl patch pvc … storage: 4Gi` — gp3 on EKS supports it) |
| `OOMKilled` | Memory limit too low | Raise `postgres.resources.limits.memory` in Git |

## After it recovers

```bash
kubectl wait --for=jsonpath='{.status.readyReplicas}'=1 sts/postgres -n shop --timeout=180s
kubectl rollout status deploy/api-green -n shop           # API becomes ready again by itself
kubectl logs -n shop -l app.kubernetes.io/name=worker --tail=20   # requeued orders get processed
```

**Long term:** a single Postgres Pod on a zonal disk is one zone failure away from an outage. On EKS use Amazon RDS Multi-AZ: set `postgres.enabled: false` and `database.host: <rds-endpoint>` in the chart values.
