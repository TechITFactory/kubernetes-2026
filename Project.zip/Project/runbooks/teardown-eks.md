# Tear down the EKS environment (and stop paying for it)

`terraform destroy` alone is not enough. Kubernetes controllers created some AWS resources that Terraform never saw:
the **NLB** (AWS Load Balancer Controller, for the Gateway), the **EBS volumes** (EBS CSI driver, for the PVCs) and
any **Spot nodes** (Karpenter). Delete those first, while their controllers still run. Otherwise they are orphaned,
keep billing, and the VPC can't be deleted.

Every step below was run at the end of the EKS test (see [logs/COMMANDS.md](../logs/COMMANDS.md), "Teardown 1/5" to "5/5").

```bash
export KUBECONFIG=~/.kube/eks        # or: kubectl config use-context <your EKS context>

# 1. Stop GitOps. Delete the parent first, or it re-creates the children you delete.
#    kubeshop has Argo CD's resources finalizer, so the shop's own objects go with it.
kubectl delete -f tests/karpenter-inflate.yaml --ignore-not-found
kubectl -n argocd delete application root
kubectl -n argocd delete applications --all

# 2. Delete what owns AWS resources, while the controllers still run
kubectl delete gateway --all -A          # Envoy removes its Service, so the LB Controller deletes the NLB
kubectl delete nodepool --all            # Karpenter terminates its Spot nodes
kubectl delete ns shop monitoring gateway   # PVCs go, so the EBS CSI driver deletes the volumes (reclaimPolicy Delete)

# 3. Check in AWS. Both numbers must be 0 before you go on.
aws elbv2 describe-load-balancers --query 'length(LoadBalancers)'
aws ec2 describe-volumes --filters Name=tag-key,Values=kubernetes.io/created-for/pvc/name --query 'length(Volumes)'

# 4. Everything Terraform created: cluster, nodes, add-ons, Helm releases, IAM, ECR (force_delete), VPC and NAT
cd infra/eks && terraform destroy

# 5. Nothing left that bills by the hour
aws eks list-clusters
aws ec2 describe-instances --filters Name=instance-state-name,Values=running,pending --query 'length(Reservations)'
aws ec2 describe-nat-gateways --filter Name=state,Values=available,pending --query 'length(NatGateways)'
aws ec2 describe-addresses --query 'length(Addresses)'
aws ec2 describe-volumes --query 'length(Volumes)'
```

If `terraform destroy` hangs on a subnet or the VPC, something from step 2 is still there. Look for leftover
load balancers, ENIs (`aws ec2 describe-network-interfaces --filters Name=vpc-id,Values=<vpc>`) and security
groups created by the LB Controller (`k8s-…`), delete them, and run `terraform destroy` again.

Kept on purpose: the EC2 Spot service-linked role (`AWSServiceRoleForEC2Spot`). It's free, it's per account,
and Karpenter needs it again next time.
