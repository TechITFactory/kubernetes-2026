# Node maintenance (drain, upgrade, return)

```bash
kubectl drain <node> --ignore-daemonsets --delete-emptydir-data   # PDBs make it wait instead of breaking the shop
# ... patch / upgrade / reboot ...
kubectl uncordon <node>
```

What the drill on this cluster showed:

- PodDisruptionBudgets work: *"Cannot evict pod as it would violate the pod's disruption budget"* — drain retried until a replacement was ready.
- `postgres-0` stays **Pending** while its zone's node is drained: its disk can't move zones. Expect a database outage for that time — or use RDS.
- The API's zone spread uses `nodeTaintsPolicy: Honor`, so a cordoned zone doesn't block rescheduling (without it one API Pod stayed Pending).

On EKS, managed node group upgrades and Karpenter do the drain for you — and respect the same PDBs.
