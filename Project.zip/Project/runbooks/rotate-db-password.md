# Rotate the database password

The password lives in two places: inside Postgres, and in the `shop-db` Secret the apps read. Change Postgres first, then the Secret, then restart the apps (environment variables are read only at start).

```bash
NEW=$(openssl rand -hex 16)
kubectl exec -n shop postgres-0 -- psql -U shop -d shop -c "ALTER USER shop PASSWORD '$NEW'"
kubectl create secret generic shop-db -n shop --from-literal=password="$NEW" --dry-run=client -o yaml | kubectl apply -f -
kubectl rollout restart deploy/api-green deploy/worker -n shop     # rolling: no downtime
kubectl rollout status deploy/api-green -n shop
```

Between the `ALTER USER` and the restart, Pods that open a *new* connection with the old password fail; existing pooled connections keep working. Do it in a quiet moment, or — on EKS — let External Secrets Operator + AWS Secrets Manager rotate it.

**Verified:** an order placed right after the rotation succeeded (`"id":350`).
