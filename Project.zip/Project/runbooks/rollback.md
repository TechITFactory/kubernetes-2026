# Roll back a bad release

**While both colours still run** (steps 1–2 of a release): set the old colour back to 100 % — instant, the old Pods are warm.

```bash
#  traffic: { blue: 100, green: 0 }
git commit -am "rollback: all traffic to blue" && git push
```

**After the old colour was switched off:** revert the commits. Argo CD recreates the old colour; do it in two commits again (old colour at 0 %, then 100 %) to avoid errors while its Pods start.

```bash
git log --oneline -- Project/helm/kubeshop/release-kind.yaml
git revert <commit-that-retired-blue>      # blue comes back at 0 %
git revert <commit-that-moved-traffic>     # traffic back to blue
git push
```

**Verified:** a `git revert` of a release commit removed `api-blue` again within a minute (logs/COMMANDS.md).
