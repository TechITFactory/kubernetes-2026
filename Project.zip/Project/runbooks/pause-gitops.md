# Pause GitOps before touching the cluster by hand

**Why:** Argo CD's self-heal puts everything back to what Git says within seconds. During an incident that is usually what you want — but not while you are investigating or running a manual fix.

**Trap (found in the database drill):** KubeShop uses an *app of apps*. The parent `root` owns the `kubeshop` Application. If you pause only `kubeshop`, `root` restores its auto-sync from Git a few seconds later. **Pause the parent first.**

```bash
# pause: parent first, then the child
kubectl patch application root     -n argocd --type merge -p '{"spec":{"syncPolicy":{"automated":null}}}'
kubectl patch application kubeshop -n argocd --type merge -p '{"spec":{"syncPolicy":{"automated":null}}}'
kubectl get application kubeshop -n argocd -o jsonpath='{.spec.syncPolicy.automated}'; echo   # empty = paused

# ... investigate / fix ...

# resume: re-enabling the parent re-applies the child's auto-sync from Git
kubectl patch application root -n argocd --type merge -p '{"spec":{"syncPolicy":{"automated":{"prune":true,"selfHeal":true}}}}'
kubectl get applications -n argocd     # everything Synced / Healthy again
```

Anything you changed by hand is reverted when you resume. If the manual fix was right, **commit it to Git first**.
