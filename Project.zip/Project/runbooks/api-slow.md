# KubeShopApiSlow

**Means:** p95 latency of `/api` is above 500 ms for 10 minutes (normal: under 10 ms).

```bash
tools/promq 'histogram_quantile(0.95, sum by (le, route) (rate(kubeshop_http_request_duration_seconds_bucket{route=~"/api.*"}[5m])))'
kubectl top pods -n shop
kubectl get hpa -n shop          # at maxReplicas? then the HPA can't help any more
```

- CPU near the request on every Pod and the HPA is at max → raise `api.autoscaling.maxReplicas` in Git (and on EKS let Karpenter add nodes).
- Only `/api/products` slow → the Redis cache isn't working: check `redis-0` and the `X-Cache` header (`HIT`/`MISS`).
- Only `/api/orders` slow → database: `kubectl top pod postgres-0 -n shop`, look for long queries with `pg_stat_activity`.
