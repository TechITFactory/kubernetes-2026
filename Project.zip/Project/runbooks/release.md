# Ship a new API version (blue/green through Git)

The live state of the API is one file: `helm/kubeshop/release-kind.yaml` (`release-eks.yaml` on EKS). Argo CD applies each commit within about a minute.

**Rule (measured):** three commits, never one. Turning a colour on *and* sending it 100 % in one step gave 40 failed requests out of 539. Three steps gave 0 out of 990.
On EKS, through the public NLB, the same steps (with a 10 % canary between) gave 0 failed out of 7,878.

```bash
# 0. build and push the image (kind: kind load docker-image; EKS: docker push to ECR)
# 1. add the new colour at 0 % — Pods start, no user traffic yet
#    green: { enabled: true, tag: "1.2.0" }   traffic: { blue: 100, green: 0 }
git commit -am "api 1.2.0: deploy green at 0%" && git push
kubectl rollout status deploy/api-green -n shop
curl -H "Host: shop.local" -H "x-color: green" http://$GW/api/info    # testers reach green directly

# 2. shift traffic — 10 % canary first, watch the dashboard, then 100 %
#    traffic: { blue: 90, green: 10 }  →  traffic: { blue: 0, green: 100 }
git commit -am "api 1.2.0: 10% canary" && git push
tools/promq 'sum by (job) (rate(kubeshop_http_requests_total{status=~"5.."}[5m])) or vector(0)'   # must stay 0

# 3. switch the old colour off
#    blue: { enabled: false }
git commit -am "api 1.2.0: retire blue" && git push
```

Next release goes the other way (green → blue).
